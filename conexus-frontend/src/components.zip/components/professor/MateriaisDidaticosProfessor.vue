<script setup>
import { ref, onMounted, computed } from 'vue';
import { useMaterialStore } from '@/stores/materialStore';
import { useTurmaStore } from '@/stores/turmaStore';
import MaterialForm from '@/components/professor/MaterialForm.vue';

const materialStore = useMaterialStore();
const turmaStore = useTurmaStore();

const turmasDoProfessor = computed(() => turmaStore.turmas || []);
const materiais = computed(() => materialStore.materiais || []);

const isLoading = ref(false); 
const dialogCadastrar = ref(false);

const materialForm = ref({
    idmaterial: null,
    titulo: '',
    descricao: '',
    tipo: null,
    idioma: '',
    nivel: null, 
    link: '',
    idturma: null, 
});

const headers = ref([
    { title: 'TÍTULO', align: 'start', key: 'titulo' }, 
    { title: 'IDIOMA', align: 'start', key: 'idiomaDescricao' },
    { title: 'NÍVEL', align: 'start', key: 'nivelDescricao' },
    { title: 'TIPO', align: 'start', key: 'tipoMaterialDescricao' },
    { title: 'LINK', align: 'start', key: 'link' }, 
    { title: 'AÇÕES', align: 'center', key: 'actions', sortable: false },
]);

async function fetchMateriais() {
    isLoading.value = true;
    try {
        await Promise.all([
            materialStore.exibir(),
            turmaStore.exibir()
        ]);
        
        // Verificação extra para o console
        if (materiais.value.length > 0) {
            console.log("Exemplo de item recebido:", materiais.value[0]);
        }
    } catch (error) {
        console.error("Erro ao carregar dados:", error);
    } finally {
        isLoading.value = false;
    }
}

function resetForm() {
    materialForm.value = {
        idmaterial: null,
        titulo: '',
        descricao: '',
        tipo: null,
        idioma: '',
        nivel: null,
        link: '',
        idturma: null, 
    };
}

function novoMaterial() {
    resetForm();
    dialogCadastrar.value = true;
}

function editItem(item) {
    materialForm.value = { ...item }; 
    dialogCadastrar.value = true;
}

async function deleteItem(item) {
    if (confirm(`Tem certeza que deseja apagar o material "${item.titulo}"?`)) {
        try {
            await materialStore.apagar(item.idmaterial);
        } catch (error) {
            console.error("Erro ao apagar material:", error);
        }
    }
}

async function salvarMaterial(formData) {
    try {
        const isEditing = !!formData.idmaterial;
        if (isEditing) {
            await materialStore.editar(formData); 
        } else {
            await materialStore.cadastrar(formData);
        }
        dialogCadastrar.value = false; 
    } catch (error) {
        console.error("Erro ao salvar material:", error);
        alert("Falha ao salvar material.");
    } 
}

onMounted(() => {
    fetchMateriais();
});
</script>

<template>
    <v-card class="material-container mt-4" max-width="1200" elevation="2"> 
        
        <v-toolbar color="orange-darken-1" density="compact" flat class="custom-toolbar">
            <v-toolbar-title class="text-white font-weight-bold ml-2">
                Meus Materiais Didáticos
            </v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn
                color="white"
                icon="mdi-plus"
                size="small"
                variant="elevated"
                @click="novoMaterial"
                title="Cadastrar Novo Material"
            ></v-btn>
        </v-toolbar>

        <v-container fluid class="pa-0">
            <v-data-table
                :headers="headers"
                :items="materiais" 
                item-value="idmaterial"
                :loading="isLoading"
                class="elevation-0 material-table"
                :items-per-page="10" 
                loading-text="Carregando materiais..."
                no-data-text="Nenhum material disponível"
            >
                <template v-slot:[`item.titulo`]="{ item }">
                    <span class="font-weight-medium">{{ item.titulo }}</span>
                </template>

                <template v-slot:[`item.idiomaDescricao`]="{ item }">
                    <v-chip size="x-small" variant="outlined" color="orange-darken-1">
                        {{ item.idiomaDescricao || 'N/A' }}
                    </v-chip>
                </template>

                <template v-slot:[`item.nivelDescricao`]="{ item }">
                    <span class="text-body-2">{{ item.nivelDescricao || 'N/A' }}</span>
                </template>

                <template v-slot:[`item.link`]="{ item }">
                    <v-btn
                        v-if="item.link"
                        icon="mdi-open-in-new"
                        variant="text"
                        size="small"
                        color="blue-darken-2"
                        :href="item.link"
                        target="_blank"
                    ></v-btn>
                    <span v-else class="text-grey text-caption">Sem link</span>
                </template>

                <template v-slot:[`item.actions`]="{ item }">
                    <div class="d-flex justify-center">
                        <v-btn
                            icon="mdi-pencil"
                            variant="text"
                            size="small"
                            color="primary"
                            class="me-2"
                            @click="editItem(item)"
                        ></v-btn>
                        <v-btn
                            icon="mdi-delete"
                            variant="text"
                            size="small"
                            color="error"
                            @click="deleteItem(item)"
                        ></v-btn>
                    </div>
                </template>
                
                <template #no-data>
                    <div class="pa-10 text-center" v-if="!isLoading">
                        <v-icon size="60" color="grey-lighten-1">mdi-book-open-variant</v-icon>
                        <p class="text-h6 text-grey-darken-1 mt-3">Sua lista de materiais está vazia.</p>
                        <v-btn color="orange-darken-1" variant="text" @click="novoMaterial">Cadastrar Primeiro Material</v-btn>
                    </div>
                </template>
            </v-data-table>
        </v-container>
    </v-card>

    <v-dialog v-model="dialogCadastrar" max-width="600px" persistent>
        <MaterialForm 
            v-if="dialogCadastrar"
            v-model="materialForm" 
            :turmasDisponiveis="turmasDoProfessor" 
            @save="salvarMaterial"
            @close="dialogCadastrar = false"
        />
    </v-dialog>
</template>

<style scoped>
.material-container {
    border-radius: 8px;
    margin: 0 auto; 
    overflow: hidden;
}

.custom-toolbar {
    background-color: #ffb300 !important; 
    border-radius: 0 !important;
}

.material-table :deep(th) {
    font-weight: bold !important;
    text-transform: uppercase !important;
    font-size: 0.75rem !important; 
    background-color: #fafafa !important;
}

.material-table :deep(td) {
    font-size: 0.875rem; 
}
</style>