<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useTurmaStore } from '@/stores/turmaStore';

const router = useRouter(); 
const turmaStore = useTurmaStore();

// Mapeia os dados da store
const turmas = computed(() => turmaStore.turmas || []);
const isLoading = ref(false);

// HEADERS: Ajustados para o padrão camelCase (padrão de saída do .NET JSON)
const headers = ref([
    { title: 'Sala', align: 'start', key: 'sala' },
    { title: 'Idioma', align: 'start', key: 'idiomaDescricao' },
    { title: 'Nível', align: 'start', key: 'nivelDescricao' },
    { title: 'Professor', align: 'start', key: 'nomeFuncionario' },
    { title: 'Dias', align: 'start', key: 'diasSemana' },
    { title: 'Horário', align: 'start', key: 'horaInicio' },
    { title: 'Ações', align: 'center', key: 'actions', sortable: false },
]);

function handleMarcarPresenca(item) {
    router.push({
        name: 'RegistroPresenca', 
        params: { turmaId: item.idturma }
    });
}

function goToDashboard() {
    router.push({ path: '/professor/dashboard' });
}

onMounted(async () => { 
    isLoading.value = true;
    try {
        await turmaStore.exibir();
        
        // VERIFICAÇÃO DE DADOS (Caso continue sem exibir, olhe o console do navegador F12)
        if (turmaStore.turmas.length > 0) {
            console.log("Campos recebidos da API:", Object.keys(turmaStore.turmas[0]));
        }
    } catch (error) {
        console.error("Erro ao carregar turmas:", error);
    } finally {
        isLoading.value = false;
    }
});
</script>

<template>
    <v-card class="turma-container mt-5" max-width="1200" elevation="2">
        <v-toolbar color="orange-darken-1" density="compact" flat class="custom-toolbar">
            <v-toolbar-title class="text-white font-weight-bold ml-2">Minhas Turmas</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn icon="mdi-close" variant="text" size="small" color="white" @click="goToDashboard"></v-btn>
        </v-toolbar>

        <v-container fluid class="pa-0">
            <v-data-table 
                :headers="headers" 
                :items="turmas" 
                item-key="idturma" 
                :loading="isLoading" 
                class="elevation-0 turma-table"
                no-data-text="Nenhuma turma vinculada encontrada."
            >
                <template #[`item.sala`]="{ value }">
                    <span class="font-weight-medium">{{ value || 'N/A' }}</span>
                </template>

                <template #[`item.idiomaDescricao`]="{ value }">
                    <v-chip size="x-small" color="orange-darken-1" variant="outlined">
                        {{ value || 'N/A' }}
                    </v-chip>
                </template>

                <template #[`item.diasSemana`]="{ value }">
                    {{ value || 'Não definido' }}
                </template>

                <template #[`item.horaInicio`]="{ value }">
                    <div class="d-flex align-center">
                        <v-icon size="small" class="mr-1">mdi-clock-outline</v-icon>
                        {{ value || '--:--' }}
                    </div>
                </template>

                <template #[`item.actions`]="{ item }">
                    <v-btn color="#ffb300" size="small" rounded="pill" @click="handleMarcarPresenca(item)">
                        <v-icon start icon="mdi-account-check" size="18"></v-icon> 
                        Presença
                    </v-btn>
                </template>
            </v-data-table>
        </v-container>
    </v-card>
</template>

<style scoped>
.turma-container { border-radius: 12px; margin: 20px auto; overflow: hidden; }
.custom-toolbar { background-color: #ffb300 !important; }
.turma-table :deep(thead th) {
    background-color: #fafafa !important;
    font-weight: 800 !important;
    text-transform: uppercase !important;
    font-size: 0.75rem !important; 
}
</style>