<script setup>
import { ref, computed, onMounted } from 'vue';
import { useCalendarioAulaStore } from '@/stores/calendarioAulaStores';
import AulasForm from './AulasFrom.vue'; 

const store = useCalendarioAulaStore();
const currentDate = ref(new Date()); 
const showForm = ref(false);
const selectedAula = ref({});
const isEditing = ref(false);
const loading = ref(false);

const diasDaSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const statusAulaOptions = [
    { title: 'Agendada', value: 'agendada', color: '#1E88E5' }, 
    { title: 'Realizada', value: 'realizada', color: '#43A047' }, 
    { title: 'Reagendada', value: 'reagendada', color: '#FB8C00' },
    { title: 'Cancelada', value: 'cancelada', color: '#E53935' }
];

const getStatusColor = (status) => {
    const option = statusAulaOptions.find(opt => opt.value === status);
    return option ? option.color : '#ffb300';
};

// Agora utiliza apenas os dados reais vindos da Store
const todasAsAulas = computed(() => {
    return store.aulas || [];
});

const daysInMonth = computed(() => {
    const year = currentDate.value.getFullYear();
    const month = currentDate.value.getMonth();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const lastDateOfMonth = new Date(year, month + 1, 0).getDate();
    
    const days = [];
    for (let i = 0; i < firstDayOfMonth; i++) {
        days.push({ day: null });
    }
    
    for (let i = 1; i <= lastDateOfMonth; i++) {
        const dataFormatada = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        const aulasDoDia = todasAsAulas.value.filter(aula => aula.dataAula === dataFormatada);
        
        days.push({
            day: i,
            dateStr: dataFormatada,
            events: aulasDoDia
        });
    }
    return days;
});

const currentMonthName = computed(() => {
    return currentDate.value.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
});

function prevMonth() { currentDate.value = new Date(currentDate.value.setMonth(currentDate.value.getMonth() - 1)); }
function nextMonth() { currentDate.value = new Date(currentDate.value.setMonth(currentDate.value.getMonth() + 1)); }

function abrirInclusao() {
    isEditing.value = false;
    selectedAula.value = {};
    showForm.value = true;
}

function abrirEdicaoParaForm(aula) {
    selectedAula.value = { ...aula };
    isEditing.value = true;
    showForm.value = true;
}

const formatarData = (dataStr) => {
    if (!dataStr) return "";
    const partes = dataStr.split('-');
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
};

onMounted(async () => {
    loading.value = true;
    try {
        await store.exibir(); 
    } catch (e) {
        console.error("Erro ao carregar aulas da API:", e);
    } finally {
        loading.value = false;
    }
});
</script>

<template>
    <v-container fluid class="pa-0 fill-height bg-surface">
        <v-row no-gutters class="fill-height">
            <v-col cols="12" md="8" class="pa-4">
                <v-card elevation="2" rounded="lg" class="fill-height d-flex flex-column border">
                    <v-toolbar color="surface" flat>
                        <v-btn icon="mdi-chevron-left" @click="prevMonth" :disabled="loading"></v-btn>
                        <v-toolbar-title class="text-capitalize font-weight-bold">
                            {{ loading ? 'Carregando...' : currentMonthName }}
                        </v-toolbar-title>
                        <v-btn icon="mdi-chevron-right" @click="nextMonth" :disabled="loading"></v-btn>
                        <v-spacer></v-spacer>
                        <v-btn color="#ffb300" theme="dark" prepend-icon="mdi-plus" variant="flat" class="font-weight-bold" @click="abrirInclusao">
                            CADASTRAR AULA
                        </v-btn>
                    </v-toolbar>

                    <v-divider></v-divider>

                    <div class="d-flex flex-wrap pa-3 justify-center">
                        <div v-for="status in statusAulaOptions" :key="status.value" class="d-flex align-center mx-3">
                            <v-icon size="12" :color="status.color" class="mr-1">mdi-circle</v-icon>
                            <span class="text-caption font-weight-bold opacity-80">{{ status.title }}</span>
                        </div>
                    </div>
                    
                    <v-divider></v-divider>

                    <v-sheet class="pa-4 flex-grow-1 overflow-y-auto" color="transparent">
                        <div class="calendar-header mb-2">
                            <div v-for="d in diasDaSemana" :key="d">{{ d }}</div>
                        </div>
                        <div class="calendar-grid">
                            <div v-for="(d, index) in daysInMonth" :key="index" class="day-cell">
                                <template v-if="d.day">
                                    <span class="day-number">{{ d.day }}</span>
                                    <div class="events-container">
                                        <div 
                                            v-for="aula in d.events" 
                                            :key="aula.idaula" 
                                            class="mini-event"
                                            :style="{ backgroundColor: getStatusColor(aula.status) }"
                                            @click.stop="abrirEdicaoParaForm(aula)"
                                        >
                                            {{ aula.horaInicio }} {{ aula.observacoes }}
                                        </div>
                                    </div>
                                </template>
                            </div>
                        </div>
                    </v-sheet>
                </v-card>
            </v-col>

            <v-col cols="12" md="4" class="pa-4 bg-surface border-s overflow-y-auto" style="max-height: 100vh;">
                <div class="d-flex align-center mb-6">
                    <v-icon color="#ffb300" size="large" class="mr-2">mdi-format-list-bulleted</v-icon>
                    <h2 class="text-h6 font-weight-black text-uppercase">Agenda de Atividades</h2>
                </div>
                
                <v-list lines="three" color="transparent">
                    <v-list-item
                        v-for="aula in todasAsAulas"
                        :key="aula.idaula"
                        class="mb-3 rounded-lg border-s-lg shadow-sm item-agenda"
                        :style="{ borderLeftColor: getStatusColor(aula.status) + ' !important' }"
                        @click="abrirEdicaoParaForm(aula)"
                    >
                        <v-list-item-title class="font-weight-bold" :style="{ color: getStatusColor(aula.status) }">
                            {{ aula.observacoes || 'Aula' }}
                        </v-list-item-title>
                        <v-list-item-subtitle class="font-weight-black opacity-90">
                            <v-icon size="small">mdi-clock-outline</v-icon> {{ aula.horaInicio }} - {{ aula.horaFim }}
                        </v-list-item-subtitle>
                        <v-list-item-subtitle class="text-caption opacity-70">
                            {{ formatarData(aula.dataAula) }} | Sala: {{ aula.sala }}
                        </v-list-item-subtitle>
                    </v-list-item>

                    <v-list-item v-if="todasAsAulas.length === 0 && !loading" class="text-center opacity-60">
                        Nenhuma aula encontrada.
                    </v-list-item>
                </v-list>
            </v-col>
        </v-row>

        <AulasForm v-model="showForm" :is-editing="isEditing" :initial-data="selectedAula" @refresh="store.exibir" />
    </v-container>
</template>

<style scoped>
.calendar-header {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    text-align: center;
    font-weight: 900;
    font-size: 0.75rem;
    opacity: 0.6;
}

.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    border-top: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
    border-left: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
}

.day-cell {
    min-height: 110px;
    padding: 4px;
    border-right: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
    border-bottom: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
    background: rgb(var(--v-theme-surface));
}

.day-cell:hover {
    background-color: rgba(var(--v-border-color), 0.02);
}

.day-number {
    font-size: 0.9rem;
    font-weight: 800;
}

.mini-event {
    color: white !important;
    font-size: 0.65rem;
    padding: 2px 5px;
    border-radius: 4px;
    margin-top: 2px;
    cursor: pointer;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: bold;
    transition: transform 0.1s;
}

.mini-event:hover {
    transform: scale(1.02);
    filter: brightness(1.1);
}

.item-agenda {
    background-color: rgba(var(--v-border-color), 0.05);
}

.border-s-lg { border-left: 6px solid !important; }
.shadow-sm { box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important; }
.opacity-80 { opacity: 0.8; }
.opacity-70 { opacity: 0.7; }
</style>