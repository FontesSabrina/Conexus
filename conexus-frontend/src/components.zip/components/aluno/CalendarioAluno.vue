<script setup>
import { ref, computed, onMounted } from 'vue';
// AJUSTE: O nome do import agora coincide com o seu arquivo físico calendarioAulaStores.js
import { useCalendarioAulaStore } from '@/stores/calendarioAulaStores'; 
import { useFuncionarioStore } from '@/stores/funcionarioStore'; 

// --- STORES E ESTADO ---
const calendarioAulaStore = useCalendarioAulaStore();
const funcionarioStore = useFuncionarioStore();

const aulasDoMes = computed(() => calendarioAulaStore.aulas);
const isLoading = computed(() => calendarioAulaStore.isLoading); 

const dataAtual = ref(new Date()); 
const diasDaSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

// --- FUNÇÕES DE CALENDÁRIO ---
const mesDoCalendario = computed(() => dataAtual.value.getMonth());
const anoDoCalendario = computed(() => dataAtual.value.getFullYear());

function mudarMes(delta) {
    const novaData = new Date(dataAtual.value);
    novaData.setMonth(novaData.getMonth() + delta);
    dataAtual.value = novaData;
}

function buscarAulasPorDia(dataObjeto) {
    if (!aulasDoMes.value || aulasDoMes.value.length === 0) return [];

    // Formata a data do calendário para YYYY-MM-DD
    const ano = dataObjeto.getFullYear();
    const mes = String(dataObjeto.getMonth() + 1).padStart(2, '0');
    const dia = String(dataObjeto.getDate()).padStart(2, '0');
    const dataStringCalendario = `${ano}-${mes}-${dia}`;

    return aulasDoMes.value.filter(aula => {
        // Pega a data que vem da API (tratando as variações de nome de campo)
        const dataCampo = aula.dataaula || aula.dataAula;
        const dataAulaISO = dataCampo ? dataCampo.split('T')[0] : '';
        return dataAulaISO === dataStringCalendario;
    }).map(aula => {
        // Tenta encontrar o nome do professor na store de funcionários
        const profId = aula.idfuncionario || aula.idFuncionario;
        const professorObj = funcionarioStore.funcionarios?.find(f => f.idfuncionario === profId);
        
        return {
            ...aula,
            horainicio: (aula.horainicio || aula.horaInicio || '00:00').substring(0, 5),
            professorNome: professorObj ? professorObj.nome : 'Professor'
        };
    });
}

function getDiasDoMes() {
    const ano = anoDoCalendario.value;
    const mes = mesDoCalendario.value;
    const primeiroDia = new Date(ano, mes, 1);
    const ultimoDia = new Date(ano, mes + 1, 0);
    const numDias = ultimoDia.getDate();
    const diaDaSemanaInicio = primeiroDia.getDay(); 
    
    const dias = [];
    for (let i = 0; i < diaDaSemanaInicio; i++) {
        dias.push({ isVazio: true });
    }

    const hoje = new Date().toLocaleDateString('pt-BR');
    
    for (let i = 1; i <= numDias; i++) {
        const dataDia = new Date(ano, mes, i);
        dias.push({ 
            isVazio: false, 
            numero: i, 
            isHoje: dataDia.toLocaleDateString('pt-BR') === hoje,
            aulas: buscarAulasPorDia(dataDia)
        });
    }

    while (dias.length % 7 !== 0) {
        dias.push({ isVazio: true });
    }
    return dias;
}

const diasDoCalendario = computed(() => getDiasDoMes());

// --- CICLO DE VIDA ---
onMounted(async () => {
    // Carrega os dados necessários ao montar o componente
    if (funcionarioStore.exibir) await funcionarioStore.exibir(); 
    await calendarioAulaStore.exibir(); 
});

function abrirModalAula(aula) {
    alert(`Aula com: ${aula.professorNome}\nHorário: ${aula.horainicio}\nLocal: ${aula.sala || 'Não informado'}`);
}

</script>

<template>
    <v-container fluid class="pa-6">
        <h3 class="text-h5 mb-4 font-weight-medium">Calendário de Aulas</h3>
        <v-divider class="mb-8"></v-divider>

        <v-card class="calendar-card" elevation="4">
            <v-card-title class="headline d-flex justify-space-between align-center pa-4 bg-primary-custom text-white">
                <v-btn icon @click="mudarMes(-1)" variant="text" color="white">
                    <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
                <span class="text-h6 font-weight-bold text-uppercase">
                    {{ dataAtual.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }) }}
                </span>
                <v-btn icon @click="mudarMes(1)" variant="text" color="white">
                    <v-icon>mdi-chevron-right</v-icon>
                </v-btn>
            </v-card-title>

            <v-row no-gutters class="text-center py-3 font-weight-bold border-b bg-grey-lighten-4">
                <v-col v-for="dia in diasDaSemana" :key="dia" class="text-caption text-uppercase">{{ dia }}</v-col>
            </v-row>
            
            <div v-if="isLoading" class="text-center pa-10">
                <v-progress-circular indeterminate color="#2fa99e"></v-progress-circular>
                <p class="mt-4 text-grey">Sincronizando aulas...</p>
            </div>

            <div v-else class="calendar-grid">
                <div 
                    v-for="(dia, index) in diasDoCalendario" 
                    :key="index"
                    class="calendar-day"
                    :class="{ 'is-vazio': dia.isVazio }"
                >
                    <div class="day-content" v-if="!dia.isVazio">
                        <div class="day-header">
                            <span class="day-number" :class="{ 'today-circle': dia.isHoje }">
                                {{ dia.numero }}
                            </span>
                        </div>
                        
                        <div class="aulas-container">
                            <v-sheet 
                                v-for="aula in dia.aulas.slice(0, 3)" 
                                :key="aula.idaula"
                                elevation="1"
                                class="aula-card text-truncate"
                                @click.stop="abrirModalAula(aula)"
                            >
                                <strong>{{ aula.horainicio }}</strong> {{ aula.professorNome.split(' ')[0] }}
                            </v-sheet>
                            
                            <div v-if="dia.aulas.length > 3" class="more-aulas">
                                +{{ dia.aulas.length - 3 }} aulas
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </v-card>
    </v-container>
</template>

<style scoped>
.bg-primary-custom {
    background-color: #2fa99e !important;
}

.calendar-grid {
    display: flex;
    flex-wrap: wrap;
    border-left: 1px solid #e0e0e0;
}

.calendar-day {
    flex: 0 0 14.2857%;
    max-width: 14.2857%;
    min-height: 120px;
    border-right: 1px solid #e0e0e0;
    border-bottom: 1px solid #e0e0e0;
    background-color: white;
}

.is-vazio {
    background-color: #f5f5f5;
}

.day-content {
    padding: 4px;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.day-header {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 4px;
}

.day-number {
    font-size: 0.85rem;
    font-weight: 600;
    padding: 4px;
}

.today-circle {
    background-color: #2fa99e;
    color: white;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.aulas-container {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.aula-card {
    font-size: 0.7rem;
    padding: 2px 5px;
    background-color: #e0f2f1;
    border-left: 3px solid #2fa99e;
    cursor: pointer;
    border-radius: 2px;
}

.aula-card:hover {
    background-color: #b2dfdb;
}

.more-aulas {
    font-size: 0.65rem;
    color: #757575;
    text-align: center;
    margin-top: 2px;
}
</style>