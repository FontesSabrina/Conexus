import { defineStore } from "pinia";
import api from "@/plugins/axios";

export const useTurmaStore = defineStore("turma", {
  state: () => ({
    turmas: []
  }),

  actions: {
    async exibir() {
      try {
        const res = await api.get("/Turma/buscartodos");
        // Certifique-se que res.data.data é um Array
        this.turmas = res.data.data || [];
        return true;
      } catch (error) {
        console.error("Erro ao listar turmas", error);
        return false;
      }
    },

    async adicionar(turma) {
      try {
        const res = await api.post("/Turma/inserir", {
          ...turma,
          idturma: 0,
          horainicio: "12:00:00", // Padronizado para minúsculo
        });
        this.turmas.push(res.data.data);
        return true;
      } catch (error) {
        console.error("Erro ao cadastrar", error);
        return false;
      }
    },

    async atualizar(idturma, turma) {
      try {
        const res = await api.put("/Turma/atualizar", {
          idturma,
          ...turma
        });
        const index = this.turmas.findIndex(t => t.idturma === idturma);
        if (index !== -1) {
          this.turmas[index] = { ...this.turmas[index], ...res.data.data };
        }
        return true;
      } catch (error) {
        console.error("Erro ao atualizar", error);
        return false;
      }
    }
  }
});