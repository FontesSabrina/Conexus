// import { defineStore } from "pinia";
// import api from '@/plugins/axios'

// //  separar data e hora 
// const splitDateTime = (dateTimeString) => {
//     if (!dateTimeString) return { dataaula: null, horainicio: null };
//     const [dataaula, timePart] = dateTimeString.split('T');
//     const horainicio = timePart ? timePart.substring(0, 5) : "00:00";
//     return { dataaula, horainicio };
// };

// export const useCalendarioAulaStore = defineStore('calendarioAula', {
//     state: () => ({
//         aulas: []
//     }),

//     actions: {
//         // GET
//         async exibir() {
//             try {
//                 const dados = await api.get('/CalendarioAula/buscartodos');
//                 this.aulas = [...dados.data.data];
//                 console.log("Dados carregados via exibir", dados);
//                 return true;
//             } catch (erro) {
//                 console.log("Erro ao carregar os dados (exibir)", erro);
//                 return false;
//             }
//         },

//         // GET buscartodos
//         async buscartodos() {
//             try {
//                 const dados = await api.get('/CalendarioAula/buscartodos');
//                 this.aulas = [...dados.data.data];
//                 console.log("Dados carregados via buscartodos", dados);
//                 return true;
//             } catch (erro) {
//                 console.log("Erro ao carregar os dados (buscartodos)", erro);
//                 return false;
//             }
//         },

//         // POST inserir
//         async adicionar(aula) {
//             try {
//                 const { dataaula, horainicio } = splitDateTime(aula.start);
//                 const { horainicio: horafim } = splitDateTime(aula.end);

//                 const payload = {
//                     idaula: 0,
//                     dataAula: dataaula,
//                     horaInicio: horainicio,
//                     horaFim: horafim,
//                     idfuncionario: aula.professor_id || 0,
//                     idturma: aula.turma_id || 0,
//                     idmaterial: aula.idmaterial || 0,
//                     sala: aula.sala_id || "",
//                     observacoes: aula.conteudo || aula.title || "",
//                     linkReuniao: aula.link_reuniao || "",
//                     aulaExtra: true
//                 };

//                 const dados = await api.post('/CalendarioAula/inserir', payload);
//                 this.aulas.push(dados.data.data);
//                 return true;
//             } catch (erro) {
//                 console.log("Erro ao inserir aula", erro);
//                 return false;
//             }
//         },

//         // PUT atualizar
//         async atualizar(id, aula) {
//             try {
//                 const { dataaula, horainicio } = splitDateTime(aula.start);
//                 const { horainicio: horafim } = splitDateTime(aula.end);

//                 const payload = {
//                     idaula: id,
//                     dataAula: dataaula,
//                     horaInicio: horainicio,
//                     horaFim: horafim,
//                     idfuncionario: aula.professor_id || 0,
//                     idturma: aula.turma_id || 0,
//                     idmaterial: aula.idmaterial || 0,
//                     sala: aula.sala_id || "",
//                     observacoes: aula.conteudo || aula.title || "",
//                     linkReuniao: aula.link_reuniao || "",
//                     aulaExtra: true
//                 };

//                 const dados = await api.put('/CalendarioAula/atualizar', payload);
                
//                 const index = this.aulas.findIndex(item => item.idaula === id);
//                 if (index !== -1) {
//                     this.aulas[index] = { ...this.aulas[index], ...dados.data.data };
//                 }
//                 return true;
//             } catch (erro) {
//                 console.log("Erro ao atualizar aula", erro);
//                 return false;
//             }
//         },

//         // DELETE excluir/{id}
//         async deleteAula(id) {
//             try {
//                 await api.delete(`/CalendarioAula/excluir/${id}`);
//                 this.aulas = this.aulas.filter(item => item.idaula !== id);
//                 return true;
//             } catch (erro) {
//                 console.log("Erro ao apagar aula", erro);
//                 return false;
//             }
//         }
//     }
// });

import { defineStore } from "pinia";
import api from '@/plugins/axios'

// Função auxiliar para converter o formato de data/hora que vem da API
const formatarDadosAula = (aula) => ({
    ...aula,
    // Garante que o Vue encontre as propriedades independente de PascalCase ou camelCase
    idaula: aula.idaula || aula.idAula,
    dataaula: aula.dataAula || aula.dataaula, 
    horainicio: aula.horaInicio || aula.horainicio,
    horafim: aula.horaFim || aula.horafim
});

export const useCalendarioAulaStore = defineStore('calendarioAula', {
    state: () => ({
        aulas: [],
        isLoading: false, // Adicionado para controlar o skeleton/loader no Vue
    }),

    actions: {
        async exibir() {
            this.isLoading = true;
            try {
                const response = await api.get('/CalendarioAula/buscartodos');
                // Mapeia os dados garantindo a compatibilidade de nomes de campos
                const listaBruta = response.data.data || [];
                this.aulas = listaBruta.map(aula => formatarDadosAula(aula));
                
                console.log("Aulas carregadas:", this.aulas);
                return true;
            } catch (erro) {
                console.error("Erro ao carregar calendário:", erro);
                return false;
            } finally {
                this.isLoading = false;
            }
        },

        async adicionar(aula) {
            try {
                // Prepara o payload para o C# (usando os nomes do DTO)
                const payload = {
                    dataAula: aula.dataaula, // O C# espera DataAula
                    horaInicio: aula.horainicio,
                    horaFim: aula.horafim,
                    idfuncionario: aula.idfuncionario,
                    idturma: aula.idturma,
                    idmaterial: aula.idmaterial,
                    sala: aula.sala,
                    observacoes: aula.observacoes,
                    linkReuniao: aula.linkReuniao,
                    aulaExtra: aula.aulaExtra || false
                };

                const response = await api.post('/CalendarioAula/inserir', payload);
                if (response.data.success) {
                    this.aulas.push(formatarDadosAula(response.data.data));
                }
                return true;
            } catch (erro) {
                console.error("Erro ao inserir aula", erro);
                return false;
            }
        },

        async deleteAula(id) {
            try {
                await api.delete(`/CalendarioAula/excluir/${id}`);
                this.aulas = this.aulas.filter(item => (item.idaula || item.idAula) !== id);
                return true;
            } catch (erro) {
                console.error("Erro ao apagar aula", erro);
                return false;
            }
        }
    }
});